# Ad Soyad: Doğa Ezel Zorlu
# Öğrenci Numarası: 20253006009
# Tarih: 18.10.2026
import itertools
import pytest
from uzay_oyunu.akis import fibonacci_generator, yakit_gostergesi, satirlari_oku, ayristir, uzun_yolculuklar, rota_sayaci
from uzay_oyunu.istatistik import (gezegen_adlari_buyuk_map, gezegen_adlari_buyuk_comp, en_az_iki_baglanti_filter, en_az_iki_baglanti_comp, toplam_baglanti_sum, toplam_baglanti_sayisi_reduce, hizli_yolculuk)
# Görev 1 Testi: Fibonacci Üreteci
# Açıklama: Bu test, fibonacci_generator fonksiyonunun doğru Fibonacci sayıları ürettiğini doğrular.
def test_fibonacci_generator():
    g = fibonacci_generator()
    assert next(g) == 0
    assert next(g) == 1
    assert next(g) == 1
    assert list(itertools.islice(fibonacci_generator(), 12)) == [ 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    assert list(itertools.takewhile(lambda x: x < 100, fibonacci_generator())) == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    g_reuse = fibonacci_generator()
    ilk_liste = list(itertools.islice(g_reuse, 3))
    ikinci_liste = list(itertools.islice(g_reuse, 3))
    assert ilk_liste == [0, 1, 1]
    assert ikinci_liste == [2, 3, 5]

# Görev 2 Testi: Yakıt Göstergesi
# Açıklama: Bu test, yakit_gostergesi fonksiyonunun doğru yakıt seviyelerini ürettiğini doğrular.
def test_yakit_gostergesi():
    g = yakit_gostergesi(100, 30)
    assert list(g) == [100, 70, 40, 10, 0]
    g_hata = yakit_gostergesi(10, 10)
    assert next(g_hata) == 10
    with pytest.raises(StopIteration):
        next(g_hata)

# Görev 3 Testi: Seyir Defteri Boru Hattı
# Açıklama: Bu test, satirlari_oku, ayristir ve uzun_yolculuklar fonksiyonlarının doğru şekilde çalıştığını doğrular.
def test_seyir_defteri_boru_hatti(tmp_path):
    test_dosya = tmp_path / "test_seyir.txt"
    test_dosya.write_text("dünya -> sirius 12\n#bakım molası\nsirius -> orion 8", encoding="utf-8")
    satirlar = satirlari_oku(str(test_dosya))
    kayitlar = list(ayristir(satirlar))
    assert len(kayitlar) == 2
    assert kayitlar[0] == ("dünya", "sirius", 12)
    assert kayitlar[1] == ("sirius", "orion", 8)
    satirlar2 = satirlari_oku(str(test_dosyasi))
    kayitlar2 = ayristir(satirlar2)
    uzunlar = list(uzun_yolculuklar(kayitlar2, 10))
    assert len(uzunlar) == 1
    assert uzunlar[0] == ("dünya", "sirius", 12)

# Görev 4 Testi : Önbellekli Rota Sayacı
# Açıklama: Bu test,derinlemesine rota sayımının ve @lru_cache mekanizmasının doğru çalışıp çalışmadığını test eder.
def test_rota_sayaci():
    ornek_harita = {
        "dünya": ["sirius", "orion"],
        "sirius": ["dünya"],
        "orion": ["dünya"]
    }
    sayici = rota_sayaci(ornek_harita)
    assert sayici("dünya", 3) == 4

# Görev 5 Testi : map, filter, reduce ve partial
# Açıklama: Bu test,map/filter/reduce fonksiyonları ile liste üreteçlerinin (comprehensions) aynı sonucu verdiğini ve partial fonksiyonunun parametreyi sabitlediğini doğrular.
def test_istatistik_fonksiyonlari():
    test_liste = ["dünya", "mars"]
    assert gezegen_adlari_buyuk_map(test_liste) == ["DÜNYA", "MARS"]
    assert gezegen_adlari_buyuk_comp(test_liste) == ["DÜNYA", "MARS"]
    ornek_harita = {"dünya": ["sirius", "orion"], "sirius": ["dünya"]}
    assert en_az_iki_baglanti_filter(ornek_harita) == ["dünya"]
    assert en_az_iki_baglanti_comp(ornek_harita) == ["dünya"]
    assert toplam_baglanti_sum(ornek_harita) == 3
    assert toplam_baglanti_sayisi_reduce(ornek_harita) == 3
    assert hizli_yolculuk("Dünya", "Mars") == "Dünya gezegeninden mars gezegenine 6 birim yolculuk yapılıyor."