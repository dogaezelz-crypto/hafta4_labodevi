# Ad Soyad: Doğa Ezel Zorlu
# Öğrenci Numarası: 20253006009
# Tarih: 18.10.2026
# Görev 5: map, filter, reduce ve partial
# Açıklama: Bu program, map, filter, reduce ve partial fonksiyonlarını kullanarak gezegen adlarını büyük harfe çevirir, en az iki bağlantısı olan gezegenleri filtreler, toplam bağlantı sayısını hesaplar ve belirli bir hızla yolculuk yapmayı sağlar.
from typing import List, Dict
from functools import reduce, partial
# 1. Gezegen Adları
def gezegen_adlari_buyuk_map(gezegenler: List[str]) -> List[str]:
    return list(map(str.upper, gezegenler))
def gezegen_adlari_buyuk_comp(gezegenler: List[str]) -> List[str]:
    return [gezegen.upper() for gezegen in gezegenler]

# 2. Bağıntı Filtreleme
def en_az_iki_baglanti_filter(baglantilar: Dict[str, List[str]]) -> List[str]:
    return list(filter(lambda gezegen: len(baglantilar[gezegen]) >= 2, baglantilar))
def en_az_iki_baglanti_comp(baglantilar: Dict[str, List[str]]) -> List[str]:
    return [gezegen for gezegen, komsular in baglantilar.items() if len(komsular) >= 2]
    
# 3. Toplam Bağlantı Sayısı
def toplam_baglanti_sayisi_reduce(baglantilar: Dict[str, List[str]]) -> int:
    return reduce(lambda acc, gezegen: acc + len(bagintilar[gezegen]), baglantilar, 0)
def toplam_baglanti_sum(baglantilar: Dict[str, List[str]]) -> int:
    return sum(len(komsular) for komsular in baglantilar.values())

# 4.Partial
def yolculuk(kaynak: str, hedef: str, hiz: int) -> str:
    return f"{kaynak} gezegeninden {hedef} gezegenine {hiz} birim hızla yolculuk yapılıyor."
hizli_yolculuk = partial(yolculuk, hiz=6)
