# Uzay Oyun Akış İstatistikleri
# Görev 4: Önbellek Performans Raporu
Bu rapor, bir gezegenden diğerine giden yolları bulan 'rota_sayaci' fonksiyonunun 20 adım derinlik ('adim=20') için '@lru_cache' dekoratörünü kullanılmadan ve kullanılarak yapılan performans ölçüm sonuçlarını içerir.
**Hesaplanan Adım Sayısı (Depth):**20
**@lru_cache Olmadan Çalışma Süresi:** ~4.242 saniye
**@lru_cache İle Çalışma Süresi:** ~0.0001 saniye
**Önbellek Bilgisi (Cache Info)** CacheInfo(hits=38, misses=21, maxsize=None, currsize=21)
# Performans Analizi
'@lru_cache' kullanılmadığında algoritma, aynı gezegenler üzerindeki tekrarlayan yolları her seferinde sıfırdan hesaplandığı için işlemciyi yormakta ve saniyeler sürmektedir. '@lru_cache' (Memoization) mekanizması devreye girdiğinde ise daha hesaplanan tüm ara rotalar hafızada tutulur.Bilgisayar aynı hesaba denk geldiğinde hafızadan anında çektiği için işlem süresi milisaniyeler seviyesine düşerek muazzam bir bellek ve hız verimliliği sağlamıştır.